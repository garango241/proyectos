sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, Filter,FilterOperator) {
	"use strict";

	return Controller.extend("DemoApp3.DemoApp3.controller.View1", {
		
	/*onInit: function () {
		 	var model1 = new sap.ui.model.json.JSONModel();
			model1.loadData("model/FormData.json");
			sap.ui.getCore().setModel(model1);
		}*/

	//P2Formulario simple Odata
		 /*onInit: function () {
		 	var oForm = this.getView().byId("idSimpleForm");
			oForm.bindElement("Model>/ProductSet('HT-1000')");
		 }*/
		 
	//P3 Listado no requiere controlador
	
	//P4 Filtros 
	
	onFilterProducts : function(oEvent){
		
		//Build filter array
		var aFilter = [], sQuery = oEvent.getParameter("query"),
			//retrieve list control
			oList = this.getView().byId("productsList"),
			//get binding for aggregation `items`
			oBinding = oList.getBinding("items");
			
		if(sQuery){
			aFilter.push(new Filter("ProductID", FilterOperator.Contains, sQuery));
		}
		//Apply filter an empty filter array simply removes the filter
		//which will make all entries visible again 
		oBinding.filter(aFilter);
	}

	});
});